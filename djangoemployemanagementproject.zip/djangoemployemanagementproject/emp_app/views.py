from django.db.models import Q
from django.shortcuts import render,HttpResponse
from emp_app.models import Role,Employee,Department
from datetime import datetime
# Create your views here.
def index(request):
    return render(request,'home.html')

def all_emp(request):
    emps = Employee.objects.all()
    return render(request,'all_emp.html',context={'emps':emps})

def add_emp(request):
    if request.method=='POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        salary= int(request.POST['salary'])
        bonus = int(request.POST['bonus'])
        phone = int(request.POST['phone'])
        role = request.POST['role']
        dept = request.POST['department']
        new_emp= Employee(first_name=first_name,last_name=last_name,salary=salary,bonus=bonus,phone=phone,dept_id=dept,role_id=role,hire_date=datetime.now())
        new_emp.save()
        return HttpResponse('Employee Added Successfully !!!! .. . .')
    elif request.method=='GET':
        return render(request,'add_emp.html')
    else:
        return HttpResponse("An Exception Occourd! Employee has not been added.. .. .")

def remove_emp(request,emp_id=0):
    if emp_id:
        try:
            emp_to_be_removed=Employee.objects.get(id=emp_id)
            emp_to_be_removed.delete()
            return HttpResponse("<h1>Employee removed successfully... .. .<\h1>")
        except:
            return HttpResponse('please provide valid employee id')
    emps = Employee.objects.all()
    return render(request,'remove_emp.html',context={'emps':emps})

def filter_emp(request):
    if request.method=='POST':
        name = request.POST['name']
        dept=request.POST['department']
        role=request.POST['role']
        emps=Employee.objects.all()
        if name:
            emps=emps.filter(Q(first_name__icontains=name)| Q(last_name__icontains=name))
        if dept:
            emps=emps.filter(dept__name=dept)
        if role:
            emps=emps.filter(role__name=role)
        return render(request,"all_emp.html",{'emps':emps})
    elif request.method == 'GET':
        return render(request,"filter_emp.html")
    else:
        return HttpResponse('Invalid item search  plz search a valid item')
